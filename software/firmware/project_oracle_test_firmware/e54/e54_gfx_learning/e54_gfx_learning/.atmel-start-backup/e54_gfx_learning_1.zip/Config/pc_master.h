/*
 * pc_master.h
 *
 * Created: 5/3/2020 6:47:27 PM
 *  Author: Penguin
 */ 
#ifndef _PC_MASTER_H_
#define _PC_MASTER_H_

// usart debug settings
#define DEBUG_MAX_BUFFER_SIZE (128)


#endif