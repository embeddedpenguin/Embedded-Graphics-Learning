#ifndef _P_TCC_H_
#define _P_TCC_H_

#include "oracle.h"
extern struct timer_descriptor p_tcc_inst;

void p_tcc_init(void);


#endif