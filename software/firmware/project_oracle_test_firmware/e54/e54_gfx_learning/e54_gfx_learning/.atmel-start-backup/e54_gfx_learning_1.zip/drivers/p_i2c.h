#ifndef _P_I2C_H_
#define _P_I2C_H_

#include "oracle.h"

extern struct i2c_m_sync_desc p_i2c_master;

void p_i2c_init(void);

#endif